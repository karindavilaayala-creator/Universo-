/* PARA MI AMOR BONITO ❤️ - JavaScript */
/* Contraseña especial: 1105 */

const PASSWORD_SECRETA = "1105";

/* 1) Verificar la contraseña */
function verificarPassword() {
    const input       = document.getElementById("passwordInput");
    const errorMsg    = document.getElementById("errorMsg");
    const lockScreen  = document.getElementById("lockScreen");
    const mainContent = document.getElementById("mainContent");
    const valor = input.value.trim();

    if (valor === PASSWORD_SECRETA) {
        errorMsg.classList.remove("show");
        lockScreen.classList.add("unlocked");
        setTimeout(() => {
            lockScreen.style.display = "none";
            mainContent.classList.remove("hidden");
            mainContent.classList.add("show");
            lanzarCorazonesExtra();
        }, 700);
    } else {
        errorMsg.classList.add("show");
        const card = document.querySelector(".lock-card");
        card.classList.remove("shake");
        void card.offsetWidth;
        card.classList.add("shake");
        input.value = "";
        input.focus();
    }
}

/* Entrar con la tecla ENTER */
document.addEventListener("DOMContentLoaded", () => {
    const input = document.getElementById("passwordInput");
    if (input) {
        input.addEventListener("keydown", (e) => {
            if (e.key === "Enter") verificarPassword();
        });
        input.focus();
    }
    generarCorazonesFondo();
});

/* 2) Corazones flotantes de fondo (continuos) */
function generarCorazonesFondo() {
    const container = document.getElementById("heartsContainer");
    if (!container) return;
    const emojis = ["❤️", "💕", "💖", "💗", "💞", "🫀", "💝", "🌷", "🐢", "👑"];
    setInterval(() => {
        const heart = document.createElement("span");
        heart.classList.add("floating-heart");
        heart.textContent = emojis[Math.floor(Math.random() * emojis.length)];
        heart.style.left = Math.random() * 100 + "vw";
        heart.style.fontSize = (16 + Math.random() * 24) + "px";
        const dur = 6 + Math.random() * 6;
        heart.style.animationDuration = dur + "s";
        container.appendChild(heart);
        setTimeout(() => heart.remove(), dur * 1000);
    }, 450);
}

/* 3) Lluvia extra de corazones al desbloquear */
function lanzarCorazonesExtra() {
    const container = document.getElementById("heartsContainer");
    if (!container) return;
    const emojis = ["❤️", "💕", "💖", "💗", "💞", "💝", "💛"];
    for (let i = 0; i < 40; i++) {
        setTimeout(() => {
            const heart = document.createElement("span");
            heart.classList.add("floating-heart");
            heart.textContent = emojis[Math.floor(Math.random() * emojis.length)];
            heart.style.left = Math.random() * 100 + "vw";
            heart.style.fontSize = (20 + Math.random() * 28) + "px";
            const dur = 4 + Math.random() * 4;
            heart.style.animationDuration = dur + "s";
            container.appendChild(heart);
            setTimeout(() => heart.remove(), dur * 1000);
        }, i * 60);
    }
}